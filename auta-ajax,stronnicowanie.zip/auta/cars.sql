-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sty 16, 2025 at 07:22 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cars`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `favorites`
--

CREATE TABLE `favorites` (
  `idUser` int(11) NOT NULL,
  `idProperty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`idUser`, `idProperty`) VALUES
(58, 73),
(58, 78),
(59, 73),
(65, 73);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `properties`
--

CREATE TABLE `properties` (
  `idProperty` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `address` varchar(100) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `datePosted` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastModifiedBy` int(11) DEFAULT NULL,
  `lastModifiedDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`idProperty`, `ownerId`, `address`, `description`, `price`, `type`, `datePosted`, `lastModifiedBy`, `lastModifiedDate`) VALUES
(78, 58, 'BMW E36', 'Benzyna&#13;&#10;Rok produkcji: 2005&#13;&#10;Silnik: 318i (1.8L, M40)&#13;&#10;Mail: user@user.pl', 7000.00, NULL, '2025-01-16 16:01:56', 1, '2025-01-16 18:13:54'),
(79, 1, 'Audi A3 8V', 'Benzyna,&#13;&#10;Konie mechaniczne: za dużo, Silnik: za mocny, &#13;&#10;mail: oliwia@gmail.com', 100000.00, NULL, '2025-01-16 17:51:55', 1, '2025-01-16 18:13:04'),
(80, 66, 'Porshe 911 GT3', '&#13;&#10;Mail: porshe@911.com', 7777777.00, NULL, '2025-01-16 18:17:46', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `property_images`
--

CREATE TABLE `property_images` (
  `idImage` int(11) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `imagePath` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `property_images`
--

INSERT INTO `property_images` (`idImage`, `property_id`, `imagePath`) VALUES
(131, 78, 'uploads/property_67892d74233ac3.67721331.jpg'),
(132, 79, 'uploads/property_6789473b956467.15321287.jpg'),
(133, 80, 'uploads/property_67894d4a8d9984.70851833.jpg');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `roles`
--

CREATE TABLE `roles` (
  `idRole` int(11) NOT NULL,
  `roleName` varchar(255) NOT NULL,
  `isActive` varchar(100) DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`idRole`, `roleName`, `isActive`, `dateCreated`) VALUES
(1, 'user', 'yes', '2024-05-27 17:29:22'),
(2, 'moderator', 'yes', '2024-05-27 17:29:48');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `userrole`
--

CREATE TABLE `userrole` (
  `idUser` int(11) NOT NULL,
  `idRole` int(11) NOT NULL,
  `assignedDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userrole`
--

INSERT INTO `userrole` (`idUser`, `idRole`, `assignedDate`) VALUES
(1, 1, '2024-06-03 18:20:00'),
(1, 2, '2024-05-30 18:36:43'),
(58, 1, '2024-06-02 23:03:04'),
(59, 2, '2024-06-02 23:03:37'),
(60, 1, '2024-06-03 17:53:12'),
(61, 1, '2024-06-07 17:44:45'),
(62, 1, '2024-06-08 08:25:21'),
(63, 1, '2024-06-08 08:25:47'),
(64, 2, '2024-06-09 15:09:00'),
(65, 1, '2024-06-10 12:18:25'),
(66, 1, '2025-01-16 18:14:50');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `idUser` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `dateCreated` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastLogin` timestamp NULL DEFAULT NULL,
  `lastModifiedBy` int(11) DEFAULT NULL,
  `lastModifiedDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idUser`, `login`, `password`, `email`, `firstName`, `lastName`, `dateCreated`, `lastLogin`, `lastModifiedBy`, `lastModifiedDate`) VALUES
(1, '2741be847eacddcb3f8c835f0379fed574cb010185aee672e2aa99ecbb5c7715', '$2y$10$ZuEujzLt5Iv4Vzvzxq30a.EzYYDEoh8sox3ujzFEOp2qjNkeKnSka', 'oliwia@gmail.com', 'Oliwia', 'Bracik', '2025-01-05 19:36:43', '2025-01-16 17:43:37', 1, '2025-01-07 17:09:50'),
(58, '04f8996da763b7a969b1028ee3007569eaf3a635486ddab211d512c85b9df8fb', '$2y$10$uqkAz2nDWyFD.sXFQdVqiee/T1FOtKC6t5vl56eoo5bYWS9EuaoMa', 'user@gmail.com', 'User', 'user', '2025-01-06 00:03:03', '2025-01-16 15:44:07', 58, '2025-01-07 16:28:25'),
(59, 'cfde2ca5188afb7bdd0691c7bef887baba78b709aadde8e8c535329d5751e6fe', '$2y$10$ZfVynv7LCD/qsh9L9GzyMuoPkVveoA5zpugraObgm9OdETyrjk0N6', 'moderator@moderator.pl', 'Moderator', 'moderator', '2025-01-07 00:03:37', '2025-01-09 16:03:52', NULL, NULL),
(60, '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08', '$2y$10$BrtuYOJpJySgppsNXIvjv.BfEYTEyyfid9duO2Ja1tBspMlX1Zd/u', 'test@testujemy.pl', 'test', 'test', '2025-01-10 18:53:12', '2025-01-10 19:17:08', 60, '2025-01-10 19:00:23'),
(66, '929260ad9b9ea9fe0f3553dd964f4ff3deb5792efd031a2b90f573fe91f012bb', '$2y$10$F5j68VyuUWVvc.MWYVBnEO6PmZVaI8vLbRaF.NxdZdPjtcwRba5rO', 'auto@auto.pl', 'porshe', 'niebawem', '2025-01-16 18:14:50', '2025-01-16 18:14:56', NULL, NULL);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`idUser`,`idProperty`);

--
-- Indeksy dla tabeli `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`idProperty`),
  ADD KEY `Properties_Users_FK` (`ownerId`),
  ADD KEY `Properties_Users_FKv1` (`lastModifiedBy`);

--
-- Indeksy dla tabeli `property_images`
--
ALTER TABLE `property_images`
  ADD PRIMARY KEY (`idImage`),
  ADD KEY `property_id` (`property_id`);

--
-- Indeksy dla tabeli `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`idRole`),
  ADD UNIQUE KEY `roleName` (`roleName`);

--
-- Indeksy dla tabeli `userrole`
--
ALTER TABLE `userrole`
  ADD PRIMARY KEY (`idUser`,`idRole`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUser`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `Users_Users_FK` (`lastModifiedBy`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `idProperty` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `property_images`
--
ALTER TABLE `property_images`
  MODIFY `idImage` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `idRole` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `Properties_Users_FK` FOREIGN KEY (`ownerId`) REFERENCES `users` (`idUser`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `Properties_Users_FKv1` FOREIGN KEY (`lastModifiedBy`) REFERENCES `users` (`idUser`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `property_images`
--
ALTER TABLE `property_images`
  ADD CONSTRAINT `property_images_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`idProperty`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `Users_Users_FK` FOREIGN KEY (`lastModifiedBy`) REFERENCES `users` (`idUser`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
