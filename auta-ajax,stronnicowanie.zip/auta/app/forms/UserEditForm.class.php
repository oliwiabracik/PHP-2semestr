<?php

namespace app\forms;

class UserEditForm {
    public $email;
    public $firstName;
    public $lastName;
    public $password;
    public $confirm_password;
}
?>
