<?php

namespace app\forms;

class RegisterForm {
    public $login;
    public $password;
    public $confirm_password;
    public $email;
    public $firstName;
    public $lastName;
}

?>
