<?php

namespace app\forms;

class PropertyManageForm {
    public $address;
    public $description;
    public $price;
    public $type;
    public $property_id;
    public $images = [];
    public $audios = [];

}

?>
