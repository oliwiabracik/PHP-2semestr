<?php

namespace app\forms;

class PropertyListForm {
    public $page;
    public $address;
}

?>
