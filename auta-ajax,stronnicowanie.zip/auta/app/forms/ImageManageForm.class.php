<?php

namespace app\forms;

class ImageManageForm {
    public $propertyId;
}

?>
