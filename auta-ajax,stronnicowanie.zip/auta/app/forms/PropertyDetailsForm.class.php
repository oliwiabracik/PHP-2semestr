<?php

namespace app\forms;

class PropertyDetailsForm {
    public $id;
    public $address;
    public $description;
    public $price;
    public $type;
    public $images = [];
    public $audios = [];

}
