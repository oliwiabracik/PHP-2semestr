<?php

namespace app\forms;

class FavoritesForm {
    public $property_id;
    public $user_id;
}

?>
