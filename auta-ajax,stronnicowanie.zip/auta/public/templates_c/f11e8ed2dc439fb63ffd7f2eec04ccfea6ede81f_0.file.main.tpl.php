<?php
/* Smarty version 4.3.2, created on 2025-01-16 19:05:44
  from 'C:\xampp\htdocs\auta\app\views\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.2',
  'unifunc' => 'content_67894a789a8d60_69069911',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f11e8ed2dc439fb63ffd7f2eec04ccfea6ede81f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\auta\\app\\views\\main.tpl',
      1 => 1737050743,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_67894a789a8d60_69069911 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_31425346867894a789a59b0_65054545', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "template.tpl");
}
/* {block 'content'} */
class Block_31425346867894a789a59b0_65054545 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_31425346867894a789a59b0_65054545',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  
<body data-home-page="main.tpl" data-home-page-title="Main Page" class="u-body" style="background-color: grey;">
    <section class="u-clearfix u-section-1" id="carousel_27ac">
        <div class="u-clearfix u-sheet u-sheet-1">
            <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
                <div class="u-layout">
                    <div class="u-layout-row">
                        <div class="u-container-style u-image u-layout-cell u-size-30 u-image-1" 
     data-image-width="800" data-image-height="827" 
     style="text-align: left; background-image: url('<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/assets/images/default_image.jpg'); background-size: cover; background-position: center;">
    <div class="u-container-layout u-container-layout-1"></div>
</div>
                        <div class="u-align-left u-container-style u-layout-cell u-size-30 u-layout-cell-2">
                            <div class="u-container-layout u-valign-middle u-container-layout-2" style="text-align: left;">
                                <h1 class="u-text u-title u-text-1">Witaj na Car Exchange!</h1>
                                <h5 class="u-text u-text-body-color u-text-2">Już dziś dodawaj ogłoszenia na Car Exchange! Przeglądaj oferty aut na sprzedaż, dodawaj własne ogłoszenia i znajdź najlepsą okazję! Niezależnie od tego, czy szukasz nowego pojazdu, czy chcesz sprzedać swoje auto, Car Exchange jest tu, aby Ci pomóc!</h5>
                                <h4 class="u-text u-text-3">Contact us!</h4>
                                <a href="mailto:cars@gmail.com" class="u-active-none u-btn u-button-style u-hover-none u-none u-text-palette-2-base u-btn-1">cars@gmail.com</a>
                                <br>
                                <a href="tel:+48 849 849 999" class="u-active-none u-btn u-button-style u-hover-none u-none u-text-palette-2-base u-btn-2">+11 000 000 000</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
</body>
<?php
}
}
/* {/block 'content'} */
}
