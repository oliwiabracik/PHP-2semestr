<?php
/* Smarty version 4.3.2, created on 2025-03-27 20:42:09
  from 'C:\xampp\htdocs\auta\app\views\properties.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.2',
  'unifunc' => 'content_67e5aa11d63564_19621377',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7f27f3f7de84305c2fe28669eed46f60d11066dc' => 
    array (
      0 => 'C:\\xampp\\htdocs\\auta\\app\\views\\properties.tpl',
      1 => 1743104528,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:property_list_partial.tpl' => 1,
  ),
),false)) {
function content_67e5aa11d63564_19621377 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17711842067e5aa11d46786_22983365', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "template.tpl");
}
/* {block 'content'} */
class Block_17711842067e5aa11d46786_22983365 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_17711842067e5aa11d46786_22983365',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

<?php $_smarty_tpl->_assignInScope('addr', (($tmp = $_smarty_tpl->tpl_vars['address']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp));?>
<body class="u-body">
  <section class="u-clearfix u-palette-5-dark-3 u-section-2" id="carousel_fd80" style="padding-bottom: 100px;">
    <div class="u-clearfix u-sheet u-sheet-1">
      <h2 style="font-weight: normal; text-align: center;">Undercover the most interesting cars!</h2>

      <?php if ((isset($_smarty_tpl->tpl_vars['logged_user']->value)) && \core\RoleUtils::inRole("user")) {?>
        <div style="text-align: center;">
          <a href="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
property_insert" class="u-btn u-button-style" style="margin: 0 auto;">Upload it</a>
        </div>
      <?php }?>

            <form id="property-search-form" class="pure-form" method="post"
            action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
find_properties"
            onsubmit="ajaxPostForm('property-search-form','<?php echo $_smarty_tpl->tpl_vars['conf']->value->action_root;?>
find_properties','property-listings'); return false;">
        <fieldset style="text-align: center;">
          <input type="text" id="address" name="address"
                 style="color: black; background-color: white; border: 1px solid #ccc; padding: 5px; width: 300px;"
                 placeholder="Search by address..." value="<?php echo $_smarty_tpl->tpl_vars['addr']->value;?>
" />
          <input type="hidden" id="page" name="page" value="<?php echo (($tmp = $_smarty_tpl->tpl_vars['page']->value ?? null)===null||$tmp==='' ? 1 ?? null : $tmp);?>
" />
          <button type="submit" class="pure-button pure-button-primary" style="background-color: black; margin-top: 5px;">Search</button>
        </fieldset>
      </form>

            <div id="property-listings" class="u-list u-list-1" style="margin-top: 30px;">
        <?php $_smarty_tpl->_subTemplateRender("file:property_list_partial.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
      </div>

            
    </div>
  </section>
</body>
<?php
}
}
/* {/block 'content'} */
}
