<?php
/* Smarty version 4.3.2, created on 2025-03-27 20:40:20
  from 'C:\xampp\htdocs\auta\app\views\property_list_partial.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.2',
  'unifunc' => 'content_67e5a9a4ddbcf5_96592901',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dc4db045e41fb05f7e46453b77c8a27bdef7eba1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\auta\\app\\views\\property_list_partial.tpl',
      1 => 1743104417,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_67e5a9a4ddbcf5_96592901 (Smarty_Internal_Template $_smarty_tpl) {
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['properties']->value, 'row');
$_smarty_tpl->tpl_vars['row']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['row']->value) {
$_smarty_tpl->tpl_vars['row']->do_else = false;
?>
  <div class="u-container-style u-list-item u-repeater-item" style="margin-bottom: 50px; min-height: 375px;">
    <div class="u-container-layout u-similar-container u-container-layout-1">
      <img src="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/<?php echo (($tmp = $_smarty_tpl->tpl_vars['row']->value['main_image'] ?? null)===null||$tmp==='' ? 'assets/images/car.jpg' ?? null : $tmp);?>
" alt=""
           class="u-image u-image-default" style="height: 400px; width: 550px;">
      <h2 style="margin-top: -400px; margin-left: 600px;"><?php echo $_smarty_tpl->tpl_vars['row']->value['address'];?>
</h2>
      <p style="margin-left: 600px;">Value: <?php echo $_smarty_tpl->tpl_vars['row']->value['price'];?>
 PLN</p>
      <p style="margin-left: 600px;">Author: <?php echo $_smarty_tpl->tpl_vars['row']->value['owner_name'];?>
</p>
      <a href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'property_details','id'=>$_smarty_tpl->tpl_vars['row']->value['idProperty']),$_smarty_tpl ) );?>
" class="u-btn" style="margin-left: 600px;">More</a>
    </div>
  </div>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

<?php if ($_smarty_tpl->tpl_vars['max_page']->value > 1 && ((($tmp = $_smarty_tpl->tpl_vars['address']->value ?? null)===null||$tmp==='' ? '' ?? null : $tmp)) == '') {?>
  <div style="margin-top: 50px; text-align: center; position: relative;">
    <?php if ($_smarty_tpl->tpl_vars['page']->value > 1) {?>
      <a class="pure-button" href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'property_list','page'=>$_smarty_tpl->tpl_vars['page']->value-1),$_smarty_tpl ) );?>
" 
         style="font-size: 200%; color: black; position: absolute; left: -50px;">&laquo; Previous</a>
    <?php }?>
    <span style="font-size: 200%;">Page <?php echo $_smarty_tpl->tpl_vars['page']->value;?>
 of <?php echo $_smarty_tpl->tpl_vars['max_page']->value;?>
</span>
    <?php if ($_smarty_tpl->tpl_vars['page']->value < $_smarty_tpl->tpl_vars['max_page']->value) {?>
      <a class="pure-button" href="<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['url'][0], array( array('action'=>'property_list','page'=>$_smarty_tpl->tpl_vars['page']->value+1),$_smarty_tpl ) );?>
" 
         style="font-size: 200%; color: black; position: absolute; right: -50px;">Next &raquo;</a>
    <?php }?>
  </div>
<?php }
}
}
