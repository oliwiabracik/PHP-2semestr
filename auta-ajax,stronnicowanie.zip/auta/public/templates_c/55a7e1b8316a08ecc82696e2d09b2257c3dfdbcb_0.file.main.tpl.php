<?php
/* Smarty version 4.3.2, created on 2024-06-10 18:50:16
  from 'C:\xampp\htdocs\faberpaw\app\views\main.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.2',
  'unifunc' => 'content_66672ec801f6c2_32711776',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '55a7e1b8316a08ecc82696e2d09b2257c3dfdbcb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\faberpaw\\app\\views\\main.tpl',
      1 => 1717875088,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_66672ec801f6c2_32711776 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_107424021366672ec801ee30_45759609', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "template.tpl");
}
/* {block 'content'} */
class Block_107424021366672ec801ee30_45759609 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_107424021366672ec801ee30_45759609',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

  
<body data-home-page="main.tpl" data-home-page-title="Main Page" class="u-body" style="background-color: grey;">
    <section class="u-clearfix u-section-1" id="carousel_27ac">
        <div class="u-clearfix u-sheet u-sheet-1">
            <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
                <div class="u-layout">
                    <div class="u-layout-row">
        
                        <div class="u-align-left u-container-style u-layout-cell u-size-30 u-layout-cell-2">
                            <div class="u-container-layout u-valign-middle u-container-layout-2" style="justify-content: start;">
                                <h1 class="u-text u-title u-text-1"">Dear Artists!</h1>
                                <h5 class="u-text u-text-body-color u-text-2">Get along with artists all around the world, upload your art, meet new artists, work with them!</h5>
                                <h4 class="u-text u-text-3">Contact me!</h4>
                                <a href="mailto:venteexxx@gmail.com" class="u-active-none u-btn u-button-style u-hover-none u-none u-text-palette-2-base u-btn-1">venteexxx@gmail.com</a>
                                <a href="tel:+48777777777" class="u-active-none u-btn u-button-style u-hover-none u-none u-text-palette-2-base u-btn-2">+11 000 000 000</a>
                            </div>
                        </div>
                        <div class="u-container-style u-image u-layout-cell u-size-30 u-image-1" data-image-width="800" data-image-height="827">
                            <div class="u-container-layout u-container-layout-1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
</body>
<?php
}
}
/* {/block 'content'} */
}
